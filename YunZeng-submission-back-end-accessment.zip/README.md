initiate project
npm install

start command
npm start

```
test command
npm test
```
